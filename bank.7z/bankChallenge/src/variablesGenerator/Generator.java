

package variablesGenerator;

public class Generator {


    public static String randomName() {
        return "name" + ((int) (Math.random() * 100) + 10);
    }

    public static int randomAge() {
        return ((int) (Math.random() * 80) + 10);
    }

    public static int randomCC() {
        return ((int) (Math.random() * 1000000) + 1000000);
    }

    public static String randomMail() {
        return "mail" + ((int) (Math.random() * 100) + 10) + "@mail.com";
    }

    public static long randomPhone() {
        return ((long) (Math.random() * 1000000) + 1000000);
    }

    public static int randomIssue() {
        return ((int) (Math.random() * 3) + 1);
    }

    public static String randomComment() {
        return "I want to create " + ((int) (Math.random() * 100) + 10) + " accounts";

    }

}
